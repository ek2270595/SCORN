//MAIN
#INCLUDE CPP.H;
int main(){
	Speech();
	return NULL;
}